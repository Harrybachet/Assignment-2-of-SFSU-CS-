/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Language.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

// java.util.ResourceBundle
// - ResourceBundle is a valid approach to internationalization.
// - ResourceBundle is not required.
// - Other approaches to internationalization are available. Some of these approaches are
// more straightforward and more relevant to new CSC 220 students then ResourceBundle is.
// - Yet, curiosity for intelligence is always highly encouraged:
// https://docs.oracle.com/en/java/javase/16/docs/api/java.base/java/util/ResourceBundle.html

import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public final class Language {
    //
    // Static Data Fields
    //    
    private static final String defaultAlienSound = "~ ąļīæń ~ "; // Default


    //
    // Instance Data Fields
    //

    private char myDash = '-';
    private int n = 70;

    private String repeatDash;

    final String textColor = "\u001B[30m" + "\u001B[43m";
    final String cancelColor = "\u001B[0m";

    private static String name;
    private static String email;

    private static int cards;

    private static ResourceBundle messages;

    //
    // Constructors
    //


    public Language() {
    }

    //President president = new President("Farhan Zaidi");


    public Language(String language) {

        switch (language.toLowerCase()) {
            case "alien" -> this.populateAlienPhrases();            // Supported
            case "chinese" -> this.populateChinesePhrases();        // Future implementation
            case "french" -> this.populateFrenchPhrases();          // Future implementation
            case "spanish" -> this.populateSpanishPhrases();        // Future implementation
            case "future" -> this.populateYourLanguagePhrases();    // Future implementation
            default -> this.populateEnglishPhrases();               // Supported
        }

    }

    public static void displayAppHeader() {

        System.out.println(Config.getOfficialAppHeader());


    }

    public static Language setLanguagePreference() {


        Scanner scanner = new Scanner(System.in);
        String inputLanguage;
        while (true) {
            System.out.print("Language: ");
            inputLanguage = scanner.nextLine();
            if (Objects.equals(inputLanguage, "English")) {
                break;
            } else if (inputLanguage.equals("Alien")) {
                setLocale(new Locale("alien"));
                displayMessage();
                System.exit(0);
            } else {
                System.out.println("Language: UNSUPPORTED language. Please enter your language.");
            }


        }

        return new Language(inputLanguage);


        // return new Language();
    }

    private void populateEnglishPhrases() {

    }

    private void populateYourLanguagePhrases() {
    }

    private void populateSpanishPhrases() {
    }

    private void populateFrenchPhrases() {
    }

    private void populateChinesePhrases() {
    }

    private void populateAlienPhrases() {

    }

    public String getGreetingPhrase(int i) {
        return "SF Giants: Welcome to the SAN FRANCISCO GIANTS!";
    }

    public Object getLanguage() {
        return Config.getDefaultLanguage();
    }

    public Object getUniversityPhrase(int i) {
        return Config.getDefaultUniversity();
    }

    public Object getClubPhrase(int i) {

        return switch (i) {
            case 1 -> "\nClub:                     " + Config.getDefaultClub();
            case 2 -> "Short Name: " + getShortName();
            case 3 -> "Established in: " + getEstablishedIn();
            case 4 -> "Colors:" + getColors();
            case 5 -> "Ballpark:" + getBallPark();
            case 6 -> "World Series Titles:" + getWorldSeriesTitle();
            case 7 -> "NL Pennants:" + getNLPennants();
            case 8 -> "Division Titles:" + getDivisionTitles();
            case 9 -> "Wild Card Berths:" + getWildCardBerths();
            case 10 -> "Owners:" + getOwners();
            case 11 -> "President:" + getPresident();
            case 12 -> "General Manager:" + getGeneralManager();
            case 13 -> "Manager:" + getManager();
            default -> Config.getDefaultClub();
        };
    }

    public String getConfigPhrase(int i) {

        return switch (i) {

            case 1 -> "Language:";
            case 2 -> "Time Zone:";
            case 3 -> "Color Sequences:";
            case 4 -> "Standard Output Log:";
            case 5 -> "Standard Error Log:";
            case 6 -> "Receipt Log:";
            case 7 -> "";
            case 8 -> "Default University:";
            case 9 -> "Default Club:";
            default -> repeatDash = String.valueOf(myDash).repeat(n);
        };

    }

    public String getShortName() {
        return "              SF Giants";
    }

    public String getEstablishedIn() {
        return "          1883";
    }

    public String getColors() {
        return "                   Orange, Black, Gold, Cream";
    }

    public String getBallPark() {
        return "                 Oracle Park";
    }

    public String getWorldSeriesTitle() {
        return "      8";
    }

    public String getNLPennants() {
        return "              23";
    }

    public String getDivisionTitles() {
        return "          8";
    }

    public String getWildCardBerths() {
        return "         3";
    }

    public String getOwners() {
        return "                   San Francisco Baseball Associates LLC";
    }

    public String getPresident() {
        return "                Farhan Zaidi";
    }

    public String getGeneralManager() {
        return "          Scott Harris";
    }

    public String getManager() {
        return "                  Gabe Kapler";
    }


    private static void setLocale(Locale locale) {
        messages = ResourceBundle.getBundle("assignment02PartB.MessagesBundle", locale);
    }


    // This is just for internationalization. //
    // I know this code is long and repetitive, the deadline was near, but I have tried all I can and put my maximum effort to produce Sample output 2, so I don't lose points //

    public static void displayMessage() {
        String zone;
        Scanner scanner = new Scanner(System.in);
        System.out.print(messages.getString("hello"));
        System.out.print(" ");
        zone = scanner.next();

        System.out.println(messages.getString("hello"));
        for (int i = 0; i < 4; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.print(messages.getString("hello") + " ");
        System.out.println(messages.getString("hello"));

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.println(messages.getString("hello"));

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.println(messages.getString("hello"));

        System.out.println(messages.getString("hello"));

        ZonedDateTime pacific = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
        int milliseconds = pacific.getNano() / 1_000_000;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
        String formattedTime = pacific.format(formatter);
        String meridiem = pacific.format(DateTimeFormatter.ofPattern("a"));

        // Formatting the desired output //
        String output = String.format("%s [%04d ms] %s PDT - " + defaultAlienSound, formattedTime, milliseconds, meridiem);

        System.out.println(output + "\n");

        System.out.print(messages.getString("TimeZone") + " ");
        System.out.print(messages.getString("hello") + " ");
        System.out.print(messages.getString("TimeZone") + " ");
        System.out.print(messages.getString("hello") + " ");
        System.out.println(messages.getString("hello"));
        System.out.println(messages.getString("hello"));

        for (int i = 0; i < 2; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }

        System.out.println(messages.getString("hello") + "                 1883");

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.print(messages.getString("hello") + " , ");
        System.out.print(messages.getString("TimeZone") + " , ");
        System.out.print(messages.getString("hello") + " , ");
        System.out.println(messages.getString("hello"));
        System.out.print(messages.getString("hello") + "                 ");
        System.out.println(messages.getString("hello"));

        System.out.println(messages.getString("hello") + "                 8");
        System.out.println(messages.getString("hello") + "                 23");
        System.out.println(messages.getString("hello") + "                 8");
        System.out.println(messages.getString("hello") + "                 3");

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.println(messages.getString("hello"));

        for (int i = 0; i < 3; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.print(messages.getString("hello") + "  ");
            System.out.print(messages.getString("hello") + "\n");
        }
        System.out.println(messages.getString("hello") + "\n");


        System.out.print(messages.getString("TimeZone") + " ");
        System.out.print(messages.getString("hello") + " ");
        System.out.print(messages.getString("hello") + "  ");
        String name = scanner.nextLine();
        name = scanner.nextLine();


        System.out.print(messages.getString("TimeZone") + " ");
        System.out.print(messages.getString("hello") + " ");
        System.out.print(messages.getString("hello") + "  ");
        String email = scanner.nextLine();

        System.out.println(name + ": " + messages.getString("hello"));


        System.out.println(messages.getString("hello"));

        for (int i = 0; i < 4; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }

        System.out.println(messages.getString("hello") + "                 1899");

        for (int i = 0; i < 2; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.print(messages.getString("hello") + " , ");
        System.out.println(messages.getString("TimeZone") + " ");

        for (int i = 0; i < 3; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }
        System.out.println(messages.getString("hello") + "\n");

        System.out.print(messages.getString("TimeZone") + " ");
        System.out.print(messages.getString("hello") + " ");
        System.out.print(messages.getString("hello") + "  ");

        System.out.print("\n. . . . .\n");

        System.out.println(messages.getString("hello"));

        System.out.print(messages.getString("TimeZone") + "                 ");
        System.out.print(messages.getString("hello") + "  ");
        System.out.println(messages.getString("TimeZone") + " ");

        for (int i = 0; i < 2; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }

        System.out.println(messages.getString("hello") + "                 28");

        for (int i = 0; i < 2; i++) {
            System.out.print(messages.getString("TimeZone") + "                 ");
            System.out.println(messages.getString("hello"));
        }


        System.out.println(messages.getString("hello") + "                 2009");
        System.out.println(messages.getString("hello"));

        System.out.println(". . . . .");

        String nickname = name.length() >= 3 ? name.substring(0, 3) : name;

        System.out.print(messages.getString("TimeZone") + "  ");
        System.out.println(messages.getString("hello") + " , 28: " + messages.getString("hello") + "  " + nickname + ". " + messages.getString("hello"));


        System.out.print(messages.getString("TimeZone") + "  ");
        System.out.println(messages.getString("hello") + " , 28: " + messages.getString("hello") + " . " + messages.getString("hello"));


        System.out.print(name + ": ");
        String response = scanner.nextLine();
        System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello") + " " + messages.getString("hello") + "  " + nickname + ". " + messages.getString("hello"));


        System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello"));

        System.out.print(name + ": ");
        cards = scanner.nextInt();


        if (cards == 3) {
            System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello"));

            String sendCards = null;
            char specialChars = 'k';
            String cardMessages = null;

            // Creating the ArrayList to store data. Which ArrayList is known for //
            ArrayList<Card> cards = new ArrayList<>();

            // LITTLE EXPLANATION //

            // First I did if input is == 3. Loop through three times to get inputs for each card and print the cards three times//
            // I did a for loop for the [1][2][3] then I called the card class and put in the parameters of the object.
            // The inputs that I got from the user I put them as parameters.
            //Then I made an arrayList then stored those inputs. Then used the for each loop to print out the card if input == 3.

            for (int i = 0; i < 3; i++) {
                System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello") + " " + (i + 1) + messages.getString("hello"));

                System.out.print(name + ": [1] ");
                sendCards = scanner.next();

                System.out.print(name + ": [2] ");
                specialChars = scanner.next().charAt(0);
                // Annoying String Buffers //
                scanner.nextLine();

                System.out.print(name + ": [3] ");
                cardMessages = scanner.nextLine();

                Card p = new Card(sendCards, cardMessages, nickname, email, specialChars, "Courier", 12);
                cards.add(p);
            }

            System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello") + " " + messages.getString("hello") + "  " + nickname + ". " + messages.getString("hello") + "\n");
            // A for each loop to get data from the ArrayList and store it into getCard() method so different cards can be printed out.
            for (Card card : cards) {
                card.getCard();
                System.out.println();
            }


            System.out.print(name + ": ");
            String reply = scanner.nextLine();
            System.out.println(messages.getString("hello") + "  " + messages.getString("hello") + " , 28: " + messages.getString("hello") + " " + messages.getString("hello") + "  " + nickname + ". " + messages.getString("hello") + "\n");

            System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));
            System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));


            for (int i = 0; i < 6; i++) {
                System.out.print(name + ": ");
                String answer = scanner.next();
                if (answer.equals("abstract") || answer.equals("default") || answer.equals("yield") || answer.equals("permits") || answer.equals("Gigantes")) {

                    System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));
                    System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));
                }

                String ballGame = scanner.nextLine();
            }


            String ballGame = scanner.nextLine();

            if (ballGame.equalsIgnoreCase("Ball Game")) {

                System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));
                System.out.println(messages.getString("hello") + " " + messages.getString("hello") + " " + messages.getString("hello"));

                System.out.println(output + "\n");
            }


        }
    }


}


//
// Static Methods
//


//
// Additional Static Methods
//

//
// Instance Methods
//

//    public String getShortName(){
//        return "              SF Giants";
//    }
//    public String getEstablishedIn(){
//        return "          1883";
//    }
//    public String getColors(){
//        return "                   Orange, Black, Gold, Cream";
//    }
//
//    public String getBallPark(){
//        return "                 Oracle Park";
//    }
//
//    public String getWorldSeriesTitle(){
//        return "      8";
//    }
//    public String getNLPennants(){
//        return "              23";
//    }
//    public String getDivisionTitles(){
//        return "          8";
//    }
//    public String getWildCardBerths(){
//        return "         3";
//    }
//    public String getOwners(){
//        return "                   San Francisco Baseball Associates LLC";
//    }
//    public String getPresident(){
//        return "                Farhan Zaidi";
//    }
//    public String getGeneralManager(){
//        return "          Scott Harris";
//    }
//    public String getManager(){
//        return "                  Gabe Kapler";
//    }
//
//    //
//    // Language
//    //
