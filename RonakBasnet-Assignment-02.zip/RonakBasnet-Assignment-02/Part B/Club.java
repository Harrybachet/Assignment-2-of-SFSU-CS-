/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Club.java
 * @author: Duc Ta
 * @author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Club extends Organization {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public Club(String defaultClub) {

    }

    public static String getOfficialSong() {
        return "Take Me out to the Ball Game";
    }

    @Override
    public void displayAbout() {
        System.out.println("hint");

    }

    @Override
    public void displayMission() {

    }

    //
    // Static Methods
    //
    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //


    //
    // Language
    //
}