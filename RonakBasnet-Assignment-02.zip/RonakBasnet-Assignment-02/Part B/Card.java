/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Card.java
 * @author: Duc Ta
 * @author: <First Name> <Last Name>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Card {

    //
    // Instance Data Fields
    //
    private final int ART_SIZE;     // Please change artSize, if needed, to get an identical output
    private final String ART_FONT; // Please change artFont, if needed, to get an identical output

    private final String RECIPIENT;
    private final String MESSAGE;
    private final String SENDER_FIRST_NAME;
    private final String SENDER_EMAIL;
    private final char ART_SYMBOL;

    //
    // Constructors
    //
    public Card(String RECIPIENT, String MESSAGE, String SENDER_FIRST_NAME, String SENDER_EMAIL, char ART_SYMBOL, String ART_FONT, int ART_SIZE) {
        this.RECIPIENT = RECIPIENT;
        this.MESSAGE = MESSAGE;
        this.SENDER_FIRST_NAME = SENDER_FIRST_NAME;
        this.SENDER_EMAIL = SENDER_EMAIL;
        this.ART_FONT = ART_FONT;
        this.ART_SIZE = ART_SIZE;
        this.ART_SYMBOL = ART_SYMBOL;
    }

    //
    // Instance Methods
    //

    public void getCard() {

        try {
            SFGiantsCardGenerator.generateSFGiantsCard(RECIPIENT, MESSAGE, SENDER_FIRST_NAME, SENDER_EMAIL, ART_SYMBOL, ART_SIZE, ART_FONT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
//
// Additional Instance Methods
//


//
// Language
//


