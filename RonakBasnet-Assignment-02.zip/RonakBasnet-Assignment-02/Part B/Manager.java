/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Manager.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Manager extends Person {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public Manager() {
    }

    @Override
    public void sayGreeting(String string) {

    }

    //
    // Instance Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}