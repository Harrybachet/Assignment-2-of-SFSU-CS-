/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: ChatSession.java
 * @author: Duc Ta
 * @author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class ChatSession {

    //  Static Data Fields
    private static final char myDash = '-';
    private static final int n = 70;

    private static final String repeatDash = String.valueOf(myDash).repeat(n);

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public ChatSession() {
    }

    public ChatSession(Club club, University university) {
    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //
    private void startChatSession() {

        Timer timer = new Timer("");
        timer.getTimeZoneFormatted();

        timer.beginChat();
        System.out.println("\nSF Giants: Welcome to the SAN FRANCISCO GIANTS!");
        System.out.print(repeatDash);


    }

    private void connectChatters() {
    }

    private void chat() {
    }

    private void runQuiz() {
    }

    private void stopChatSession() {
    }

    public void runChatSession() {
        startChatSession();

        Language language = new Language();

        for (int i = 1; i < 14; i++) {
            System.out.println(language.getClubPhrase(i));
        }
        System.out.println(repeatDash);

        Player player = new Player("Buster Posey", "San Francisco Giants", "Catcher", "28", "Right", "Right", "2009");

        player.sayGreeting();

        Timer timer = new Timer("");
        timer.endChat();

        Receipt r = new Receipt();
        r.getReciept();


    }

    //
    // Language
    //
}