/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Timer.java
 * @author: Duc Ta
 * @author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.time.ZonedDateTime;
public class Timer {

    //
    // Static Data Fields
    //

    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss '[%sss ms] a z' - 'Chat session started.'");


    private static String zone;

    String timeZone;

    //
    // Constructors
    //
    public Timer(String timeZone) {
    }

    public static Timer setTimeZonePreference() {

        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Time Zone: ");
            zone = scanner.next();

            // I used switch because it looked cleaner //

            switch (zone) {
                case "PST" -> {
                    return new Timer("Pacific Standard Time in Daylight Saving");
                }
                case "CST" -> {
                    return new Timer("Central Standard Time in Daylight Saving");
                }
                case "EST" -> {
                    return new Timer("Eastern Standard Time not in Daylight Saving");
                }
                default -> System.out.println("Time Zone: INVALID time zone. Please enter your time zone.");
            }

        }
    }

    public Object getTimeZoneFormatted() {

        if (zone.equalsIgnoreCase("PST")) {
            // Pacific Standard Time //
            DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
            return "Pacific Standard Time in Daylight Saving";
        } else if (zone.equalsIgnoreCase("CST")) {
            // Central Standard Time //
            DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
            return "Central Standard Time in Daylight Saving";
        } else if (zone.equalsIgnoreCase("EST")) {
            // Eastern Standard Time //
            DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("America/New_York"));
            return "Eastern Standard Time not in Daylight Saving";
        }else{
            return "Unreachable";
        }
    }

    // I can do this beginChat method in a better way. I ran out of time to fix this portion //
    public void beginChat(){

        if(zone.equalsIgnoreCase("PST")){
            ZonedDateTime pacific = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
            int milliseconds = pacific.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = pacific.format(formatter);
            String meridiem = pacific.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s PDT - Chat session started.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

        }

        if(zone.equalsIgnoreCase("CST")){
            ZonedDateTime central = ZonedDateTime.now(ZoneId.of("America/Chicago"));
            int milliseconds = central.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = central.format(formatter);
            String meridiem = central.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s CDT - Chat session started.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

        }

        if(zone.equalsIgnoreCase("EST")){
            ZonedDateTime eastern = ZonedDateTime.now(ZoneId.of("America/New_York"));
            int milliseconds = eastern.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = eastern.format(formatter);
            String meridiem = eastern.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s EST - Chat session started.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

        }

    }


    public void endChat(){

        if(zone.equalsIgnoreCase("PST")){
            ZonedDateTime pacific = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
            int milliseconds = pacific.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = pacific.format(formatter);
            String meridiem = pacific.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s PDT - Chat session ended.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

        }

        if(zone.equalsIgnoreCase("CST")){
            ZonedDateTime central = ZonedDateTime.now(ZoneId.of("America/Chicago"));
            int milliseconds = central.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = central.format(formatter);
            String meridiem = central.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s CDT - Chat session ended.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

        }

        if(zone.equalsIgnoreCase("EST")){
            ZonedDateTime eastern = ZonedDateTime.now(ZoneId.of("America/New_York"));
            int milliseconds = eastern.getNano() / 1_000_000;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
            String formattedTime = eastern.format(formatter);
            String meridiem = eastern.format(DateTimeFormatter.ofPattern("a"));

            // Formatting the desired output //
            String output = String.format("%s [%04d ms] %s EST - Chat session ended.", formattedTime, milliseconds, meridiem);

            System.out.println(output);

    }





        // I can make the code above better by using the code below, but I didn't want to risk it because it gave the desired output so I didn't want to mess around with it.
        // If my program breaks I will get 0 :( //



//        public void setTimeZonePreference() {
//            Scanner scanner = new Scanner(System.in);
//            while (true) {
//                System.out.print("Time Zone (PST, CST, EST): ");
//                zone = scanner.next();
//
//                if (zone.equalsIgnoreCase("PST") || zone.equalsIgnoreCase("CST") || zone.equalsIgnoreCase("EST")) {
//                    break;
//                } else {
//                    System.out.println("INVALID time zone. Please enter your time zone.");
//                }
//            }
//            scanner.close();
//        }
//
//        private void printChatSession(String event) {
//            String zoneId;
//            String timeZoneAbbreviation;
//
//            switch (zone.toUpperCase()) {
//                case "PST" -> {
//                    zoneId = "America/Los_Angeles";
//                    timeZoneAbbreviation = "PDT";
//                }
//                case "CST" -> {
//                    zoneId = "America/Chicago";
//                    timeZoneAbbreviation = "CDT";
//                }
//                case "EST" -> {
//                    zoneId = "America/New_York";
//                    timeZoneAbbreviation = "EST";
//                }
//                default -> throw new IllegalStateException("Unexpected value: " + zone);
//            }
//
//            ZonedDateTime now = ZonedDateTime.now(ZoneId.of(zoneId));
//            int milliseconds = now.getNano() / 1_000_000;
//            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm:ss");
//            String formattedTime = now.format(formatter);
//            String meridiem = now.format(DateTimeFormatter.ofPattern("a"));
//
//            String output = String.format("%s [%04d ms] %s %s - Chat session %s.", formattedTime, milliseconds, meridiem, timeZoneAbbreviation, event);
//            System.out.println(output);
//        }
//
//        public void beginChat() {
//            printChatSession("started");
//        }
//
//        public void endChat() {
//            printChatSession("ended");
//        }

    //
    // Static Methods
    //

    //
    // Additional Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //
    }
}