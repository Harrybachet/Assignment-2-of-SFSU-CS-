/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Player.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import com.sun.jdi.InvalidTypeException;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import static java.lang.System.exit;

public final class Player extends Person {

    // Instance Data Fields


    private static final char myDash = '-';
    private static final int n = 70;
    private static final String repeatDash = String.valueOf(myDash).repeat(n);

    private String clubPlayer;
    private String club;
    private String position;
    private String number;
    private String bats;
    private String playerThrows;
    private String mlbDebut;

    private String name;

//    private String firstName =  ;
//    private String lastName;

    private static final String CORRECT = "Correct!";

    final String CANCEL_COLOR = "\u001B[0m";

    final String GOLD = "\u001B[33m";

    final String PURPLE = "\u001B[45m";


    //
    // Constructors
    //
    public Player(String clubPlayer, String club, String position, String number, String bats, String playerThrows, String mlbDebut) {
        this.clubPlayer = clubPlayer;
        this.club = club;
        this.position = position;
        this.number = number;
        this.bats = bats;
        this.playerThrows = playerThrows;
        this.mlbDebut = mlbDebut;
    }

    @Override
    public void sayGreeting(String string) {
        Scanner input = new Scanner(System.in);

        System.out.print("\nSF Giants: Your first name and last name, please: ");
        this.name = input.nextLine();


        System.out.print("SF Giants: Your school email address, please: ");
        String email = input.nextLine();

        System.out.println(PURPLE + GOLD + name + CANCEL_COLOR + ":" + " Welcome to my university!");
        System.out.print(repeatDash);

        University uni = new University();
        uni.displayAbout();
        System.out.println(repeatDash + "\n");

        System.out.println("SF Giants: Thank you. We are connecting you with our player...");
        System.out.println(". . . . .");
        System.out.print(repeatDash + "\n");

        Player player = new Player("Buster Posey", "San Francisco Giants", "Catcher", "28", "Right", "Right", "2009");

        player.playerAttributes();

        System.out.println(repeatDash);

        System.out.println(". . . . .");

        // Code to turn My first name into first three characters

        String nickname = name.length() >= 3 ? name.substring(0, 3) : name;

        System.out.println("Buster Posey, 28: Hello " + nickname + ". C-O-N-G-R-A-T-U-L-A-T-I-O-N-S!");

        System.out.println("Buster Posey, 28: " + PURPLE + GOLD + "SAN FRANCISCO STATE UNIVERSITY" + CANCEL_COLOR + ". Way to go!");

        System.out.print(PURPLE + GOLD + name + CANCEL_COLOR + ": ");
        String response = input.nextLine();

        System.out.println("Buster Posey, 28: Likewise, " + nickname + ". " + "Very nice chatting w/ you.");

        System.out.println("Buster Posey, 28: How many SF Giants Thank You cards would you like to order?");

        int secondResponse = 0;
        boolean validInput = false;

        for (int i = 4; i > 0; i--) {
            System.out.print(PURPLE + GOLD + name + CANCEL_COLOR + ": ");
            try {
                secondResponse = input.nextInt();
                validInput = true;
                break; // Exit the loop if the input is valid
            } catch (InputMismatchException e) {
                input.nextLine(); // Consume invalid input
                System.out.println("Please enter an INTEGER. " + (i - 1) + " tries left");
                System.out.println("java.util.InputMismatchException");
                System.out.println("Buster Posey, 28: How many SF Giants Thank You cards would you like to order?");
            }
        }


        if (validInput && secondResponse == 1) {

            System.out.println("Buster Posey, 28: In 3 lines, please provide");
            System.out.println("   [1] Recipient name ");
            System.out.println("   [2] Art symbol (a character)");
            System.out.println("   [3] Message to recipient");

            String sendCards = null;
            char specialChars = 'k';
            String messages = null;


            // Loop through one time to get input for each card //
            for (int i = 0; i < 1; i++) {

                System.out.println("Buster Posey, 28: Card #" + (i + 1) + ": ");

                System.out.print(PURPLE + GOLD + name + CANCEL_COLOR + ": [1] ");
                sendCards = input.next();

                System.out.print(name + ": [2] ");
                specialChars = input.next().charAt(0);
                input.nextLine();

                // Clearing the scanner buffer before reading the next char //
                System.out.print(name + ": [3] ");
                messages = input.nextLine();
                //input.nextLine();
            }

            System.out.println("Buster Posey, 28: Thanks, " + name + "." + " Please confirm your order:\n");

            Card p = new Card(sendCards, messages, nickname, email, specialChars, "Courier", 12);
            p.getCard();

            System.out.print("\n" + name + ": ");
            String thankYou = input.nextLine();

            System.out.println("Buster Posey, 28: Thank you again, " + nickname + "." + " See you at your graduation ceremony!\n");

            getQuiz();


        }


        if (validInput && secondResponse == 3) {
            System.out.println("Buster Posey, 28: In 3 lines, please provide");
            System.out.println("   [1] Recipient name ");
            System.out.println("   [2] Art symbol (a character)");
            System.out.println("   [3] Message to recipient");

            String sendCards = null;
            char specialChars = 'k';
            String messages = null;

            // Creating the ArrayList to store data. Which ArrayList is known for //
            ArrayList<Card> cards = new ArrayList<>();

            // LITTLE EXPLANATION //

            // First I did if input is == 3. Loop through three times to get inputs for each card and print the cards three times//
            // I did a for loop for the [1][2][3] then I called the card class and put in the parameters of the object.
            // The inputs that I got from the user I put them as parameters.
            //Then I made an arrayList then stored those inputs. Then used the for each loop to print out the card if input == 3.

            for (int i = 0; i < 3; i++) {
                System.out.println("Buster Posey, 28: Card #" + (i + 1) + ": ");

                System.out.print(PURPLE + GOLD + name + CANCEL_COLOR + ": [1] ");
                sendCards = input.next();

                System.out.print(name + ": [2] ");
                specialChars = input.next().charAt(0);
                // Annoying String Buffers //
                input.nextLine();

                System.out.print(name + ": [3] ");
                messages = input.nextLine();

                Card p = new Card(sendCards, messages, nickname, email, specialChars, "Courier", 12);
                cards.add(p);
            }

            System.out.println("Buster Posey, 28: Thanks, " + name + "." + " Please confirm your order:\n");
            // A for each loop to get data from the ArrayList and store it into getCard() method so different cards can be printed out.
            for (Card card : cards) {
                card.getCard();
                System.out.println();
            }
            System.out.print(name + ": ");
            String thankYou = input.nextLine();


            System.out.println("Buster Posey, 28: Thank you again, " + nickname + "." + " See you at your graduation ceremony!\n");

            getQuiz();
        }
    }


    public void getQuiz() {

        Scanner input = new Scanner(System.in);
        int wrongAnswer = 0;

        System.out.println("SF Giants: *** FREE TICKETS to SF GIANTS Games *** _ 1 miss allowed _");
        System.out.println("SF Giants: Which type of class has 'protected' constructors?");
        System.out.print(name + ": ");
        String answer = input.nextLine().trim();
        if (answer.equalsIgnoreCase("abstract")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        System.out.println("SF Giants: What type of method did Java 8 add to 'interface'?");
        System.out.print(name + ": ");
        String answerTwo = input.nextLine().trim();
        if (answerTwo.equalsIgnoreCase("default")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        System.out.println("SF Giants: What new keyword did Java 13 add to 'switch' statement?");
        System.out.print(name + ": ");
        String answerThree = input.nextLine().trim();
        if (answerThree.equalsIgnoreCase("yield")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        System.out.println("SF Giants: In Java 15, what keyword pairs with 'sealed'?");
        System.out.print(name + ": ");
        String answerFour = input.nextLine().trim();
        if (answerFour.equalsIgnoreCase("permits")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        System.out.println("SF Giants: Giants in Spanish?");
        System.out.print(name + ": ");
        String answerFive = input.nextLine().trim();
        if (answerFive.equalsIgnoreCase("Gigantes")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        System.out.println("SF Giants: Take me out to the...?");
        System.out.print(name + ": ");
        String answerSix = input.nextLine().trim();

        if (answerSix.equals("Ball Game")) {
            System.out.println("SF Giants: " + CORRECT);
        } else {
            System.out.println("SF Giants: Oops...");
            wrongAnswer++;
        }

        if (wrongAnswer > 1) {
            System.out.println("___ Please try again at your graduation ceremony. ___");
        } else {
            System.out.println("*** Congrats! You won FREE TICKETS to SF GIANTS Games ***");
        }


    }


    public void playerAttributes() {
        System.out.print("Player:                   " + clubPlayer + "\n");
        System.out.print("Club:                     " + club + "\n");
        System.out.print("Position:                 " + position + "\n");
        System.out.print("Number:                   " + number + "\n");
        System.out.print("Bats:                     " + bats + "\n");
        System.out.print("Throws:                   " + playerThrows + "\n");
        System.out.print("MLB Debut:                " + mlbDebut + "\n");

    }


    //
    // Language
    //

    //
    // @Override
    //


    //            System.out.println("Buster Posey, 28: Card #1: ");
//            System.out.print(name + ":" + " [1] ");
//            String sendCard = input.nextLine();
//            input.nextLine();
//            System.out.print(name + ":" + " [2] ");
//            char specialChar = input.next().charAt(0);
//            System.out.print(name + ":" + " [3] ");
//            String message = input.nextLine();
//            System.out.println("Buster Posey, 28: Card #2: ");
//            System.out.print(name + ":" + " [1] ");
//            String sendCard2 = input.nextLine();
//            input.nextLine();
//            System.out.print(name + ":" + " [2] ");
//            char specialChar2 = input.next().charAt(0);
//            System.out.print(name + ":" + " [3] ");
//            String message2 = input.nextLine();
//            System.out.println("Buster Posey, 28: Card #3: ");
//            System.out.print(name + ":" + " [1] ");
//            String sendCard3 = input.nextLine();
//            input.nextLine();
//            System.out.print(name + ":" + " [2] ");
//            char specialChar3 = input.next().charAt(0);
//            System.out.print(name + ":" + " [3] ");
//            String message3 = input.nextLine();

}
