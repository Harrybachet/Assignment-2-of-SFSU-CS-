/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: StdOutStdErrTee.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import java.io.IOException;
import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class StdOutStdErrTee extends OutputStream {

    private final String receiptLog = "./src/assignment02PartB/log/Receipt-*-*.log";

    @Override
    public void write(int b) throws IOException {

    }

    public Object getStdOutFilePath() {
        return Config.getDefaultStdOutFilePath();
    }

    public Object getStdErrFilePath() {
        return Config.getDefaultStdErrFilePath();
    }

    public void startLog() {




    }

    public void stopLog() {
//        java.io.File file = new java.io.File(Config.getDefaultLogDirectoryPath());
//        // Read data from a file
//        try (Scanner input = new Scanner(file)) {
//            while (input.hasNext()) { // Read data from a file
//                String firstName = input.next();
//                String lastName = input.next();
//                double gpa = input.nextDouble();
//                input.nextLine();
//                System.out.println(firstName + " " + lastName + " " + gpa);
//            }
//            input.close(); // Close the file
//        } catch (FileNotFoundException e) {
//            System.out.println("\t In catch: Printing e.getMessage()...");
//            System.out.println("\t In catch: " + e.getMessage());
//        } finally {
//            System.out.println("<In finally: CSC 210 - Exception handled.>");
//        }
    }

    //
    // Static Data Fields
    //

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //

    //
    // Instance Methods
    //

    //
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}