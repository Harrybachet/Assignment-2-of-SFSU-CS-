/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: OwnerGroup.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class OwnerGroup extends Organization {
    //
    // Data fields
    //

    String Owner = "San Francisco Baseball Associates LLC";

    //
    // Constructors
    //
    public OwnerGroup() {
    }

    @Override
    public void displayAbout() {
        System.out.println("San Francisco Baseball Associates LLC");
    }

    @Override
    public void displayMission() {

    }

    //
    // Instance Methods
    //

    //
    // Override
    //
}