/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: University.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class University extends Organization {
    //
    // Static Data Fields
    //
    private static final String NAME = "            San Francisco State University";
    private static final String LATIN_MOTTO = "           Experientia Docet";
    private static final String ENGLISH_MOTTO = "         Experience Teaches";
    private static final String TYPE_OF_SCHOOL = "                     Public";
    private static final String ESTABLISHMENT_YEAR = "    1899";
    private static final String LOCATION = "                 San Francisco, California, United States";
    private static final String ADDRESS = "                  1600 Holloway Avenue, San Francisco, CA 94132";
    private static final String COLORS = "                   Purple, Gold";
    private static final String NICKNAME = "                 Gators";
    private static final String MASCOT = "                   Gator";
    private static final String WEBSITE = "                  www.sfsu.edu";

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public University() {
    }


    @Override
    public void displayAbout() {
        System.out.print("\nOfficial Name:" + NAME + "\n");
        System.out.print("Motto in Latin:" + LATIN_MOTTO + "\n");
        System.out.print("Motto in English:" + ENGLISH_MOTTO + "\n");
        System.out.print("Type:" + TYPE_OF_SCHOOL + "\n");
        System.out.print("Year of Establishment:" + ESTABLISHMENT_YEAR + "\n");
        System.out.print("Location:" + LOCATION + "\n");
        System.out.print("Address:" + ADDRESS + "\n");
        System.out.print("Colors:" + COLORS + "\n");
        System.out.print("Nickname:" + NICKNAME + "\n");
        System.out.print("Mascot:" + MASCOT + "\n");
        System.out.print("Website:" + WEBSITE + "\n");
    }

    @Override
    public void displayMission() {

    }

    //
    // Instance Methods
    //

    //
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}