/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Quiz.java
 * Author: Duc Ta
 * Author: <Ronak> <Basnet>
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

import java.util.Scanner;

public final class Quiz {

    //
    // Instance Data Fields
    //

    private static final String CORRECT = "Correct!";
    //
    // Constructors
    //
    public Quiz() {
    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

//    public void getQuiz(){
//
//        Scanner input = new Scanner(System.in);
//
//        System.out.println("SF Giants: *** FREE TICKETS to SF GIANTS Games *** _ 1 miss allowed _");
//        System.out.println("SF Giants: Which type of class has 'protected' constructors?");
//        //System.out.println(name);
//        String answer = input.next();
//        System.out.println("SF Giants: What type of method did Java 8 add to 'interface'?");
//
//        System.out.println("SF Giants: What new keyword did Java 13 add to 'switch' statement?");
//        System.out.println("SF Giants: In Java 15, what keyword pairs with 'sealed'?");
//        System.out.println("SF Giants: Giants in Spanish?");
//        System.out.println("SF Giants: Take me out to the...?");
//        System.out.println("*** Congrats! You won FREE TICKETS to SF GIANTS Games ***");
//
//
//
//
//
//    }

    public String getCorrect(){
        return CORRECT;
    }

    //
    // Language
    //
}